var classlibdap_1_1fdistream =
[
    [ "fdistream", "d7/d6d/classlibdap_1_1fdistream.html#a30f09221e96f9dd1bf49ba698ccc545d", null ],
    [ "buf", "d7/d6d/classlibdap_1_1fdistream.html#af9602392d0c9dea765f2559a08dbbef5", null ]
];