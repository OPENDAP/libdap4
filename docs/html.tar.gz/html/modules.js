var modules =
[
    [ "The 'strict' mode", "d8/d1d/group__strict.html", "d8/d1d/group__strict" ],
    [ "Check_type", "dc/ddd/group__check__type.html", "dc/ddd/group__check__type" ],
    [ "Get_type", "df/dbb/group__get__type.html", null ]
];