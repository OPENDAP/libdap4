var group__strict =
[
    [ "get_strict", "d8/d1d/group__strict.html#ga202e7c06a5dc5172bc52bc1029ec8e82", null ],
    [ "set_strict", "d8/d1d/group__strict.html#gad0fb36451a4348afb0a294f709c905f2", null ]
];